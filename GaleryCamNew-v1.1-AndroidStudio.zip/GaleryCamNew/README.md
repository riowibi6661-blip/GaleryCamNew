# GaleryCamNew 1.1

Android 10+ gallery-backed handler for the standard Android camera and image-selection intents.

## What's new in 1.1
- Version code 2 / version name 1.1.
- Requests the correct image-library permission on Android 10–15, including Android 14+ selected-photo access.
- Keeps the standard `IMAGE_CAPTURE`, `GET_CONTENT`, and `PICK` intent filters.
- Returns the selected image as a `content://` URI with read permission and `ClipData`.
- When the caller supplies `MediaStore.EXTRA_OUTPUT`, copies the selected image into that destination and returns it.
- Retains the document-picker fallback for choosing an image from another provider.

## Compatibility limits
This app implements Android's public intent contracts. It can appear only in apps that actually launch an external camera or image-picker intent. Apps that embed their own camera or use private capture flows will continue to open that camera; another app cannot override that behavior.

## Build
- Android Gradle Plugin 8.13.2
- JDK 17
- compileSdk 36
- minSdk 29 (Android 10)
