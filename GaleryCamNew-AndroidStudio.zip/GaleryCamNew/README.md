# GaleryCamNew

Android Studio project for an Android 10+ gallery-backed camera intent handler.

## Behavior
- Registers as a handler for `android.media.action.IMAGE_CAPTURE`.
- Displays local images in a simple three-column gallery, newest first.
- Lets the user browse other image providers through Android's document picker.
- If the caller supplied `MediaStore.EXTRA_OUTPUT`, copies the chosen image into that destination and returns `RESULT_OK`.
- Otherwise returns the chosen `content://` URI with read permission in the result Intent.

## Requirements
- Android Studio with Android SDK Platform 36
- JDK 17
- Android Gradle Plugin 8.13.2

## Build
Open this folder in Android Studio, allow Gradle sync, then choose **Build > Build APK(s)**.

Minimum Android: 10 (API 29). Target/compile SDK: 36.

## Important compatibility note
Android apps differ in how they invoke camera capture. This project implements the standard `ACTION_IMAGE_CAPTURE` contract, including `EXTRA_OUTPUT`. Some apps use proprietary camera flows, reject gallery-backed content URIs, or require camera-specific metadata; those cases need device/app-specific testing and may not behave identically to the legacy app.
