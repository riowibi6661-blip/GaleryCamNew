package com.galerycamnew;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.ImageDecoder;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;

/**
 * GaleryCamNew: a gallery-backed replacement for a camera capture intent.
 * It never takes a new photo; it returns an existing image to the calling app.
 */
public class MainActivity extends Activity {
    private static final int REQUEST_PICK = 4101;
    private final ArrayList<Uri> images = new ArrayList<>();
    private GridView grid;
    private Uri requestedOutput;
    private boolean launchedAsCamera;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        Intent incoming = getIntent();
        launchedAsCamera = incoming != null &&
                MediaStore.ACTION_IMAGE_CAPTURE.equals(incoming.getAction());
        requestedOutput = incoming == null ? null : incoming.getParcelableExtra(MediaStore.EXTRA_OUTPUT);
        buildScreen();
        loadImages();
    }

    private void buildScreen() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xfffafafa);

        TextView title = new TextView(this);
        title.setText("GaleryCam");
        title.setTextColor(0xffffffff);
        title.setTextSize(20);
        title.setGravity(Gravity.CENTER_VERTICAL);
        title.setPadding(dp(16), 0, dp(16), 0);
        title.setBackgroundColor(0xff455a64);
        root.addView(title, new LinearLayout.LayoutParams(-1, dp(56)));

        TextView hint = new TextView(this);
        hint.setText("Pilih foto");
        hint.setTextColor(0xff333333);
        hint.setTextSize(16);
        hint.setPadding(dp(16), dp(12), dp(16), dp(8));
        root.addView(hint);

        grid = new GridView(this);
        grid.setNumColumns(3);
        grid.setVerticalSpacing(dp(3));
        grid.setHorizontalSpacing(dp(3));
        grid.setStretchMode(GridView.STRETCH_COLUMN_WIDTH);
        grid.setPadding(dp(3), dp(3), dp(3), dp(3));
        grid.setAdapter(new PhotoAdapter());
        grid.setOnItemClickListener((parent, view, position, id) -> returnImage(images.get(position)));
        root.addView(grid, new LinearLayout.LayoutParams(-1, 0, 1));

        TextView browse = new TextView(this);
        browse.setText("Jelajahi file lainnya");
        browse.setTextColor(0xff455a64);
        browse.setTextSize(16);
        browse.setGravity(Gravity.CENTER);
        browse.setPadding(dp(12), 0, dp(12), 0);
        browse.setBackgroundColor(0xffeeeeee);
        browse.setOnClickListener(v -> openDocumentPicker());
        root.addView(browse, new LinearLayout.LayoutParams(-1, dp(52)));
        setContentView(root);
    }

    private void loadImages() {
        images.clear();
        String[] projection = { MediaStore.Images.Media._ID };
        String sort = MediaStore.Images.Media.DATE_ADDED + " DESC";
        try (Cursor c = getContentResolver().query(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI, projection,
                null, null, sort)) {
            if (c != null) {
                int idCol = c.getColumnIndexOrThrow(MediaStore.Images.Media._ID);
                while (c.moveToNext()) {
                    long id = c.getLong(idCol);
                    images.add(Uri.withAppendedPath(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                            Long.toString(id)));
                }
            }
        } catch (Exception e) {
            Toast.makeText(this, "Tidak dapat memuat galeri", Toast.LENGTH_SHORT).show();
        }
        if (grid != null && grid.getAdapter() != null) ((BaseAdapter) grid.getAdapter()).notifyDataSetChanged();
    }

    private void openDocumentPicker() {
        Intent pick = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        pick.addCategory(Intent.CATEGORY_OPENABLE);
        pick.setType("image/*");
        pick.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try { startActivityForResult(pick, REQUEST_PICK); }
        catch (Exception e) { Toast.makeText(this, "Pemilih file tidak tersedia", Toast.LENGTH_LONG).show(); }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_PICK) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null) returnImage(data.getData());
            else setResult(RESULT_CANCELED);
        }
    }

    private void returnImage(Uri selected) {
        try {
            if (requestedOutput != null) {
                copyImage(selected, requestedOutput);
                Intent result = new Intent();
                result.setData(requestedOutput);
                result.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                setResult(RESULT_OK, result);
            } else {
                Intent result = new Intent();
                result.setData(selected);
                result.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                result.setClipData(android.content.ClipData.newUri(getContentResolver(), "image", selected));
                setResult(RESULT_OK, result);
            }
            finish();
        } catch (Exception e) {
            Toast.makeText(this, "Gagal mengirim foto: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void copyImage(Uri source, Uri destination) throws Exception {
        ContentResolver resolver = getContentResolver();
        try (InputStream in = resolver.openInputStream(source);
             OutputStream out = resolver.openOutputStream(destination, "w")) {
            if (in == null || out == null) throw new IllegalStateException("URI foto tidak dapat dibuka");
            byte[] buffer = new byte[64 * 1024];
            int n;
            while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
            out.flush();
        }
    }

    private int dp(int value) { return (int) (value * getResources().getDisplayMetrics().density + 0.5f); }

    private class PhotoAdapter extends BaseAdapter {
        @Override public int getCount() { return images.size(); }
        @Override public Object getItem(int position) { return images.get(position); }
        @Override public long getItemId(int position) { return position; }
        @Override public View getView(int position, View convertView, ViewGroup parent) {
            ImageView image = convertView instanceof ImageView ? (ImageView) convertView : new ImageView(MainActivity.this);
            image.setLayoutParams(new GridView.LayoutParams(-1, dp(118)));
            image.setScaleType(ImageView.ScaleType.CENTER_CROP);
            image.setBackgroundColor(0xffdddddd);
            try {
                Bitmap thumb;
                if (Build.VERSION.SDK_INT >= 29) {
                    thumb = getContentResolver().loadThumbnail(images.get(position), new android.util.Size(dp(240), dp(240)), null);
                } else {
                    thumb = MediaStore.Images.Thumbnails.getThumbnail(getContentResolver(), Long.parseLong(images.get(position).getLastPathSegment()), MediaStore.Images.Thumbnails.MINI_KIND, null);
                }
                image.setImageBitmap(thumb);
            } catch (Exception e) { image.setImageResource(android.R.drawable.ic_menu_gallery); }
            return image;
        }
    }
}
